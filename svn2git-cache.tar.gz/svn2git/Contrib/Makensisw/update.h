void CheckForUpdate(); /* Check for newer version on server and show a message to the user. */
